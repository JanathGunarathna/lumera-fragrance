package com.lumera.entity;

public enum Role {
    ROLE_CUSTOMER,
    ROLE_ADMIN
}
